# 🚚 LOGIEXPRESS 1.0

Aplicação didática de logística desenvolvida em **Python + Flask + SQLAlchemy**, preparada para execução local e publicação em cloud.

## Objetivo didático

A aplicação representa um sistema de logística já existente. Na aula de 29/09 os alunos conhecem a solução completa. Na prática de 30/09 cada grupo recebe uma nova demanda e evolui o sistema.

## Stack

- Python
- Flask
- SQLAlchemy
- PostgreSQL em produção / SQLite para desenvolvimento local
- Bootstrap 5
- Git + GitHub
- GitHub Codespaces / VS Code no navegador
- Render para publicação

## Executar localmente

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Acesse `http://127.0.0.1:5000`.

Se `DATABASE_URL` não existir, o projeto usa SQLite automaticamente.

## Publicar no Render

1. Envie o projeto para um repositório GitHub.
2. No Render, crie um Web Service a partir do repositório.
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `gunicorn app:app`
5. Configure `DATABASE_URL` apontando para PostgreSQL.
6. Configure `SECRET_KEY`.

O arquivo `render.yaml` já deixa o serviço documentado como referência.

## Estrutura

```text
logiexpress/
├── app.py
├── requirements.txt
├── render.yaml
├── .env.example
├── templates/
├── static/
├── docs/
└── tests/
```

## Próxima etapa

A versão 1.0 é a linha de base. As novas funcionalidades do dia 30/09 devem ser desenvolvidas em branches separadas, seguindo o requisito entregue a cada grupo.
